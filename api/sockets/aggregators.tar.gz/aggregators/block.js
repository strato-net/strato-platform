const Block = require('../eth/block');
const io = require('../connect/sockets');
const {LAST_BLOCK_NUMBER} = require('../constants')

function getLastBlock() {
  Block.findAll({raw: true}).then(block => {
    io.in(`ROOM_${LAST_BLOCK_NUMBER}`).emit(`EVENT_${LAST_BLOCK_NUMBER}`, block);
  });
}

setTimeout(getLastBlock, 3000)